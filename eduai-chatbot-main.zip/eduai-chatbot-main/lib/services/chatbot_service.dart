/// A service to handle chatbot queries about East Delta University (EDU).
/// It uses a predefined set of rules and keywords to find answers from
/// the provided scraped data, including specific advising and payment info.
class ChatbotService {
  /// Processes a user's query and returns a response based on scraped data.
  ///
  /// The [query] is the user's question about EDU.
  /// Returns a [String] containing the answer or a fallback message.
  String getResponse(String query) {
    final lowerCaseQuery = query.toLowerCase();

    // --- Greeting ---
    if (_isMatch(lowerCaseQuery, ['hello', 'hi', 'hey'])) {
      return "Hello! I am the East Delta University chatbot. How can I assist you with information about EDU today?";
    }

    // --- Summer '25 Advising & Payment Information (NEW SECTION) ---
    if (_isMatch(lowerCaseQuery, ["summer '25", "summer 25", "advising fee"])) {
        if (_isMatch(lowerCaseQuery, ['late'])) {
            return """
Yes, a late advising fee of BDT 1,000 will be applicable if you fail to complete your advising for SUMMER '25 by the specified deadline of May 21, 2025.

Additionally, a late fee on due tuition fees has been in effect since Summer 2024. This was previously waived from Spring 2020 to Spring 2024 due to the COVID-19 situation.
""";
        }
        return """
Here is the payment information for the SUMMER '25 semester:

**Advising Fee (First Instalment):**
This must be paid before you meet your faculty member for advising.
- For regular students: BDT 16,500
- For EBSc students: BDT 4,500

**Tuition Fee Instalments:**
Yes, you can pay in instalments. After paying the Advising Fee, the second instalment deadline is July 10, 2025.

**Previous Dues:**
Yes, you must clear all previous dues to enroll in SUMMER '25. To check your financial details, please email PAYQ@eastdelta.edu.bd.
""";
    }

    if (_isMatch(lowerCaseQuery, ['payment method', 'how to pay', 'bank deposit', 'online payment'])) {
        return """
There are three ways to pay your fees for SUMMER '25:

**Method 1: Online Payment**
- **Portal:** https://epayment.eastdelta.edu.bd/
- **Note:** A transaction processing fee of 1.522842% will be charged.
- **Help:** Call +88 01311 10 45 31, +88 01311 10 45 32, +88 01311 10 45 34 or +88 01311 10 4537.

**Method 2: On-Campus Payment**
- Bank personnel will be on campus to accept payments from May 19, 2025, to May 21, 2025.

**Method 3: Bank Deposits**
You can deposit fees at the following banks. **You must write your Student ID, Full Name, and Phone No. on the deposit slip and upload it online.**
- **BANK ASIA LTD:** A/C Name: East Delta University, A/C No. 00936000974, MCB Sk. Mujib Road Branch, Chattogram.
- **SHAHJALAL ISLAMI BANK LTD:** A/C Name: East Delta University, A/C No. 300412400000006, Muradpur branch, Chattogram.
""";
    }

    if (_isMatch(lowerCaseQuery, ['drop semester', 'skip semester'])) {
        return "Yes, if you drop a semester (e.g., Spring '25) and return for the next one (Summer '25), you will still need to pay the semester fees for all previous semesters you were not enrolled in. It is advised to pay any outstanding fees when you enroll.";
    }
    
    // --- Scholarships and Financial Aid (ENHANCED) ---
    if (_isMatch(lowerCaseQuery, ['scholarship', 'financial aid', 'waiver', 'discount', 'cost'])) {
      if (_isMatch(lowerCaseQuery, ['12 credit', 'credits'])) {
          return "Yes, it is mandatory to enroll in 12 credits in a semester to be eligible to receive and continue your scholarships.";
      }
      return """
East Delta University offers a wide range of scholarships and financial support programs.

**Important Note for Continuing Scholarships:** You MUST enroll in 12 credits each semester to remain eligible for your scholarship.

**For Undergraduate Students (at admission):**
- **Board of Trustees-Chairman’s Distinguished Scholarship:** Up to BDT 300,000 for students with Golden GPA 5.00 in both SSC & HSC.
- **BoT Grant:** Up to BDT 200,000 for students with a total GPA of 9.0 or above in SSC & HSC.
- **EDU Women Empowerment and Leadership Fund:** Up to 100% scholarship for 10 deserving female students.

**For Postgraduate Students (at admission):**
- **Alumni Scholarship:** Up to 80% scholarship on tuition for EDU alumni.
- **Professor Jamal Nazrul Islam Bursary:** Up to 75% for non-EDUVIANS with high CGPA.
- **MPPL & MA programs** have their own unique, generous scholarship schemes.

**Other Financial Support:**
- Merit-cum-need-based support (up to 100%) for existing students.
- Special quota for children of Freedom Fighters and students from underdeveloped areas (up to 100%).
- Waivers for siblings/spouses of current students or employees.
- Merit awards for outstanding academic performance during studies.

For detailed eligibility, please check the specific program page on the EDU website.
""";
    }
    
    // --- Contact Information (ENHANCED) ---
    if (_isMatch(lowerCaseQuery, ['contact', 'phone', 'email', 'address', 'location'])) {
      return """
Here is the contact information for East Delta University (EDU):

**Address:**
Abdullah Al Noman Road, Noman Society, East Nasirabad, Khulshi, Chattogram: 4209, Bangladesh.

**Phone Numbers:**
- +88 01311 10 45 31
- +88 01311 10 45 32
- +88 01311 10 45 34
- +88 01311 10 45 37
- +88 0963 81444 13

**Emails:**
- General Enquiries: enquiry@eastdelta.edu.bd
- Degree Verification: controller.exam@eastdelta.edu.bd
- Advising Questions: advising@eastdelta.edu.bd
- Financial Dues/Queries: PAYQ@eastdelta.edu.bd
""";
    }

    // --- Academic Programs ---
    if (_isMatch(lowerCaseQuery, ['undergraduate', 'bachelor', 'b.sc', 'b.a'])) {
      return """
East Delta University offers the following Undergraduate Programs:

- Bachelor of Business Administration (BBA)
- Bachelor of Science in Business Administration & Artificial Intelligence (BSBA & AI)
- Bachelor of Science in Computer Science & Engineering (B.Sc. in CSE)
- Bachelor of Science in Electrical & Electronic Engineering (B.Sc. in EEE)
- Bachelor of Science in Electronics & Telecommunication Engineering (B.Sc. in ETE)
- Bachelor of Arts (BA in English)
- Bachelor of Science (B.Sc. in Economics)
""";
    }

    if (_isMatch(lowerCaseQuery, ['postgraduate', "master's", 'm.sc', 'm.a', 'mba', 'mppl'])) {
      if(lowerCaseQuery.contains('mba')) {
        return """
The Master of Business Administration (MBA) program at EDU is designed to be technology-intensive, value-based, and focused on entrepreneurship.

**Credit Hours:**
- For students from a Business (Hons.) background: 40 credits
- For students from a Non-Business background: 43-64 credits

**Major Concentration Areas:**
Finance, Marketing, Economics, Accounting, Banking, Management, International Business, and more.

There are special considerations for job holders, including a 40% waiver on regular credit fees.
""";
      }
      if(lowerCaseQuery.contains('mppl')) {
        return """
The Master of Public Policy and Leadership (MPPL) program is an interdisciplinary program focused on "Digital and Global Governance".

**Key Features:**
- It is designed for professionals from diverse backgrounds like doctors, engineers, corporate managers, public officials, etc.
- Requires at least 1 year of work experience.
- The program is offered in three modes: Taught Mode, Mixed Mode, and Research Mode.

**Scholarships:**
Several scholarships are available, including the 'Board of Trustees-Chairman’s Leadership Award' (up to 100% waiver) and the 'EDU Corporate Leadership Award' (80% waiver for partner organizations).
""";
      }
      return """
East Delta University offers the following Postgraduate Programs:

- Master of Business Administration (MBA)
- Master of Public Policy and Leadership (MPPL)
- Master of Science in Computer Science & Engineering (M.Sc. in CSE)
- Master of Science in Electronics & Telecommunication Engineering (M.Sc. in ETE)
- Master of Science in Data Analytics and Design Thinking for Business
- Master of Arts (MA) in English
- Master of Arts (MA) in TESOL
""";
    }

    // --- Admissions ---
    if (_isMatch(lowerCaseQuery, ['admission requirement', 'how to get in', 'apply'])) {
       if (_isMatch(lowerCaseQuery, ['undergraduate', 'bachelor'])) {
         return """
Here are the general admission requirements for Undergraduate programs at EDU:

**For SSC & HSC Candidates:**
- A total GPA of 5.00 or above, with at least GPA 2.50 in each exam.
- OR, a total GPA of 6.00 or above if the GPA in one exam is between 2.00 and 2.50.
- For engineering programs (CSE, EEE, ETE), students must have Mathematics and Physics with at least a 'C' grade.

**For O-Levels/A-Levels Candidates:**
- 5 subjects in O-Levels and 2 subjects in A-Levels with a minimum total of 26.5 points.
- For engineering, Mathematics and Physics with at least a 'C' grade are required.

You can apply online through the university's website.
""";
       }
       if (_isMatch(lowerCaseQuery, ['postgraduate', "master's"])) {
          return "Admission requirements for postgraduate programs vary. For example, for M.Sc. in CSE or ETE, a relevant B.Sc. degree with a CGPA of 2.5 is needed. For MPPL, 1 year of work experience is required. Please specify the program you are interested in for more details.";
       }
      return "To apply, you can visit the university website and use the 'APPLY ONLINE' option. Admission requirements vary for undergraduate and postgraduate programs. Could you please specify which level you are interested in?";
    }

    // --- University Leadership ---
    if (_isMatch(lowerCaseQuery, ['founder', 'who started'])) {
      return "East Delta University was founded by Sayeed Al Noman in May 2005. He also serves as the Vice Chairman of the Board of Trustees (BoT) and holds an MPhil from the University of Oxford and an MSc from the London School of Economics.";
    }

    if (_isMatch(lowerCaseQuery, ['vice chancellor', 'vc'])) {
      return "The Vice-Chancellor of East Delta University is Professor Dr. Mohammed Nazim Uddin.";
    }

    // --- International Collaboration ---
    if (_isMatch(lowerCaseQuery, ['international partnership', 'exchange program', 'arkansas'])) {
      return """
East Delta University has an MoU with Arkansas State University (ASU), USA, for a 2+2 Bachelor's Degree program.

**Details:**
- Students complete the first 2 years of their undergraduate degree at EDU and the remaining 2 years at ASU.
- **Applicable Programs:** B.Sc. in Computer Science & Engineering (CSE) and B.Sc. in Electrical & Electronic Engineering (EEE).
- **Requirements:** Students must have an IELTS score of 5.5 or a TOEFL iBT score of 61.
""";
    }

    // --- Career Opportunities ---
    if (_isMatch(lowerCaseQuery, ['job', 'career', 'vacancy'])) {
      return """
EDU has a Career Opportunities section on its website for both academic and administrative positions.

**Current Administrative Opening:**
- **Position:** Executive: Outreach and Engagement
- **Vacancy:** 01
- **Deadline:** On or before July 11, 2024.
- **Requirements:** Master's degree, strong communication skills (IELTS 7+ preferred), and 1 year of similar experience.

**Academic Openings:**
There are ongoing vacancies for positions from Lecturer to Professor in various departments, including:
- Computer Science and Engineering (CSE)
- School of Business Administration (Accounting, Finance, Marketing, HRM, etc.)
- Department of English
Application deadlines for these academic roles are often far in the future (e.g., 2025), suggesting they are rolling recruitments.
""";
    }
    
    // --- University Structure ---
     if (_isMatch(lowerCaseQuery, ['schools', 'faculties', 'departments'])) {
      return """
East Delta University is organized into three main schools:

1.  **School of Business Administration** (Offers BBA, BSBA & AI, B.Sc. in Economics, MBA, MPPL, and M.Sc. in Data Analytics).
2.  **School of Science, Engineering & Technology** (Offers B.Sc. & M.Sc. in CSE, EEE, and ETE).
3.  **School of Liberal Arts & Social Science** (Offers BA, MA in English, and MA in TESOL).
""";
    }

    // --- Fallback Message ---
    return "I'm sorry, I couldn't find specific information about that in the provided data. Please try asking about admissions, programs, scholarships, contact information, advising for Summer '25, or career opportunities at East Delta University.";
  }

  /// A helper function to check if the query contains any of the keywords.
  bool _isMatch(String query, List<String> keywords) {
    return keywords.any((keyword) => query.contains(keyword));
  }
}

// --- Example Usage ---
void main() {
  final chatbot = ChatbotService();
  
  print("--- Testing Chatbot with New Information ---");

  // Test Case 1: Advising Fee
  print("\nUser: How much is the advising fee for summer '25?");
  print("Bot: ${chatbot.getResponse("How much is the advising fee for summer '25?")}");

  // Test Case 2: Payment Methods
  print("\nUser: What are the payment methods?");
  print("Bot: ${chatbot.getResponse("What are the payment methods?")}");

  // Test Case 3: Scholarship Credit Requirement
  print("\nUser: Do i need 12 credits for my scholarship?");
  print("Bot: ${chatbot.getResponse("Do i need 12 credits for my scholarship?")}");

  // Test Case 4: Dropping a semester
  print("\nUser: what happens if I drop a semester?");
  print("Bot: ${chatbot.getResponse("what happens if I drop a semester?")}");
  
  // Test Case 5: Late Fee
  print("\nUser: is there a late advising fee?");
  print("Bot: ${chatbot.getResponse("is there a late advising fee?")}");
  
  // Test Case 6: Enhanced Contact Info
  print("\nUser: what is the email for advising questions?");
  print("Bot: ${chatbot.getResponse("what is the email for advising questions?")}");

  // Test Case 7: Original Functionality Check
  print("\nUser: tell me about the undergraduate programs");
  print("Bot: ${chatbot.getResponse("tell me about the undergraduate programs")}");
}