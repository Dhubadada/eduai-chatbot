// This is the NEW widget, located at the bottom of lib/screens/chat_screen.dart

class _MessageBubble extends StatelessWidget {
  final String text;
  final bool isUser;

  const _MessageBubble({
    Key? key,
    required this.text,
    required this.isUser,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Define colors from the image for consistency
    const Color headerColor = Color(0xFF6B0F1A);
    const Color primaryTextColor = Color(0xFF3E2723);
    const Color accentColor = Color(0xFFD4B483);

    final alignment = isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor = isUser ? Colors.white : headerColor;
    final textColor = isUser ? primaryTextColor : accentColor;
    final label = isUser ? "You" : "EduAi";

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Column(
        crossAxisAlignment: alignment,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            child: Text(
              label,
              style: GoogleFonts.ebGaramond(
                color: primaryTextColor.withOpacity(0.8),
                fontSize: 14,
              ),
            ),
          ),
          Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
            decoration: BoxDecoration(
              color: bubbleColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isUser ? accentColor.withOpacity(0.7) : accentColor,
                width: isUser ? 1.5 : 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 5,
                  offset: const Offset(0, 2),
                )
              ],
            ),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Text(
              text,
              style: GoogleFonts.ebGaramond(
                color: textColor,
                fontSize: 17,
                height: 1.4, // Improves readability for serif fonts
              ),
            ),
          ),
        ],
      ),
    );
  }
}