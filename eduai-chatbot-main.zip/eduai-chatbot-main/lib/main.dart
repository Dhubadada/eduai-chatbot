// lib/main.dart

import 'package:eduai/firebase_options.dart';
import 'package:eduai/screens/auth_gate.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart'; // Import Google Fonts

void main() async {
  // Ensure Flutter is initialized
  WidgetsFlutterBinding.ensureInitialized();
  // Initialize Firebase
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Define the colors from your new design to use in the theme
    const Color pageBackgroundColor = Color(0xFFF5E8C7);
    const Color headerColor = Color(0xFF6B0F1A);
    const Color primaryTextColor = Color(0xFF3E2723);
    const Color accentColor = Color(0xFFD4B483);
    
    return MaterialApp(
      title: 'EduAi', // Updated title
      debugShowCheckedModeBanner: false,
      
      // --- THEME UPDATED HERE ---
      theme: ThemeData(
        brightness: Brightness.light, // The new theme is light
        useMaterial3: true,
        
        // Set the default font to match the new design
        fontFamily: GoogleFonts.ebGaramond().fontFamily,

        // Define the primary color palette for the app
        primaryColor: headerColor,
        scaffoldBackgroundColor: pageBackgroundColor,

        // The ColorScheme defines the core color palette for components
        colorScheme: const ColorScheme(
          brightness: Brightness.light,
          primary: headerColor, // Main interactive color (buttons, app bars)
          onPrimary: accentColor, // Color for text/icons on top of the primary color
          secondary: accentColor, // Accent color (borders, highlights)
          onSecondary: primaryTextColor, // Color for text/icons on top of the secondary color
          error: Colors.redAccent,
          onError: Colors.white,
          background: pageBackgroundColor, // The app's main background color
          onBackground: primaryTextColor, // The default text color on the background
          surface: Colors.white, // Color for card backgrounds, text fields
          onSurface: primaryTextColor, // Text color on surfaces
        ),

        // You can also define specific component themes if needed
        appBarTheme: AppBarTheme(
          backgroundColor: headerColor,
          foregroundColor: accentColor, // This sets icon and title color
          centerTitle: true,
          elevation: 0,
          titleTextStyle: GoogleFonts.ebGaramond(
            fontSize: 32,
            fontWeight: FontWeight.bold,
            color: accentColor,
          ),
        ),
      ),
      home: const AuthGate(), // This remains the same
    );
  }
}