// lib/screens/auth_gate.dart

import 'package:eduai/screens/chat_screen.dart';
import 'package:eduai/screens/login_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class AuthGate extends StatelessWidget {
  const AuthGate({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<User?>(
        // Listen to the authentication state changes from Firebase
        stream: FirebaseAuth.instance.authStateChanges(),
        builder: (context, snapshot) {
          // 1. If the connection is still loading, show a progress indicator.
          // This prevents a flicker between screens on app startup.
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          // 2. If the snapshot has data, it means the user is logged in.
          if (snapshot.hasData) {
            // Navigate to the main chat screen.
            return const ChatScreen();
          }

          // 3. If the snapshot has no data, the user is logged out.
          else {
            // Show the login screen.
            return const LoginScreen();
          }
        },
      ),
    );
  }
}