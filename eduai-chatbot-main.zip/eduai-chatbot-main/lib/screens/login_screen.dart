// lib/screens/login_screen.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _auth = FirebaseAuth.instance;
  bool _isLoading = false;

  // --- NO CHANGES TO THE LOGIC ---
  // The login/signup functionality remains the same.
  Future<void> _login() async {
    if (mounted) setState(() => _isLoading = true);
    try {
      // First, try to sign in
      await _auth.signInWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
    } on FirebaseAuthException catch (e) {
      if (e.code == 'user-not-found' || e.code == 'invalid-credential') {
        // If user not found, create a new account
        try {
          await _auth.createUserWithEmailAndPassword(
            email: _emailController.text.trim(),
            password: _passwordController.text.trim(),
          );
        } catch (e) {
          _showError(
              "Failed to create account. Please check your details and ensure the password is at least 6 characters.");
        }
      } else {
        _showError(e.message ?? "An error occurred.");
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  void _showError(String message) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.redAccent,
      ),
    );
  }
  // --- END OF UNCHANGED LOGIC ---


  @override
  Widget build(BuildContext context) {
    // Define colors from the image for easy reuse
    const Color pageBackgroundColor = Color(0xFFF5E8C7);
    const Color headerColor = Color(0xFF6B0F1A);
    const Color primaryTextColor = Color(0xFF3E2723);
    const Color accentColor = Color(0xFFD4B483);

    return Scaffold(
      backgroundColor: pageBackgroundColor,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 30.0),
            child: Container(
              // This container creates the main card with border and rounded corners
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: accentColor, width: 1.5),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 10,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18), // Clip children to rounded shape
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Header Section
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      color: headerColor,
                      child: Center(
                        child: Text(
                          'EduAi',
                          style: GoogleFonts.ebGaramond(
                            color: accentColor,
                            fontSize: 48,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),

                    // Form Body Section
                    Container(
                      color: pageBackgroundColor,
                      padding: const EdgeInsets.fromLTRB(24, 20, 24, 30),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // "Log in" Title and University Seal
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Text(
                                'Log in',
                                style: GoogleFonts.ebGaramond(
                                  color: primaryTextColor,
                                  fontSize: 40,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const Spacer(),
                              // IMPORTANT: Add your university seal image to assets
                              Image.asset(
                                'assets/edu_logo.png',
                                height: 70,
                              ),
                            ],
                          ),
                          const SizedBox(height: 24),

                          // Email Label and Field
                          Text(
                            'Email address',
                            style: GoogleFonts.ebGaramond(
                              color: primaryTextColor,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: _emailController,
                            keyboardType: TextInputType.emailAddress,
                            style: const TextStyle(color: primaryTextColor),
                            decoration: _buildTextFieldDecoration(),
                          ),
                          const SizedBox(height: 20),

                          // Password Label and Field
                          Text(
                            'Password',
                            style: GoogleFonts.ebGaramond(
                              color: primaryTextColor,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: _passwordController,
                            obscureText: true,
                            style: const TextStyle(color: primaryTextColor),
                            decoration: _buildTextFieldDecoration(),
                          ),
                          const SizedBox(height: 30),

                          // Login Button
                          _isLoading
                              ? const Center(child: CircularProgressIndicator(color: headerColor))
                              : SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton(
                                    onPressed: _login,
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: headerColor,
                                      foregroundColor: accentColor,
                                      padding: const EdgeInsets.symmetric(vertical: 16),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      elevation: 0,
                                    ),
                                    child: Text(
                                      'Log in', // Text changed to match the image
                                      style: GoogleFonts.ebGaramond(
                                        fontSize: 22,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // A new helper method to style TextFields consistently like the image
  InputDecoration _buildTextFieldDecoration() {
    return InputDecoration(
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      filled: true,
      fillColor: Colors.white.withOpacity(0.9),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: const Color(0xFFD4B483).withOpacity(0.7), width: 1.5),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: Color(0xFFD4B483), width: 2),
      ),
    );
  }
}