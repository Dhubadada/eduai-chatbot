// lib/screens/chat_screen.dart

import 'package:eduai/services/chatbot_service.dart';
// Note: The external message_bubble.dart is no longer needed for this screen's new design.
// import 'package:eduai/widgets/message_bubble.dart'; 
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

// This data class remains unchanged
class ChatMessage {
  final String text;
  final bool isUser;
  ChatMessage({required this.text, required this.isUser});
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({Key? key}) : super(key: key);

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _controller = TextEditingController();
  final _chatbotService = ChatbotService();
  final List<ChatMessage> _messages = [];

  // --- NO CHANGES TO THE LOGIC ---
  // All functions for sending and receiving messages are the same.
  @override
  void initState() {
    super.initState();
    _addBotMessage(
        "Hello! I am EduAI. Ask me anything about East Delta University.");
  }

  void _addBotMessage(String text) {
    setState(() {
      _messages.insert(0, ChatMessage(text: text, isUser: false));
    });
  }

  void _sendMessage() {
    final text = _controller.text;
    if (text.isEmpty) return;

    setState(() {
      _messages.insert(0, ChatMessage(text: text, isUser: true));
    });

    final botResponse = _chatbotService.getResponse(text);
    
    Future.delayed(const Duration(milliseconds: 500), () {
      _addBotMessage(botResponse);
    });

    _controller.clear();
    // Hide keyboard after sending
    FocusScope.of(context).unfocus();
  }
  // --- END OF UNCHANGED LOGIC ---


  @override
  Widget build(BuildContext context) {
    // Define colors from the image for consistency
    const Color pageBackgroundColor = Color(0xFFF5E8C7);
    const Color headerColor = Color(0xFF6B0F1A);
    const Color primaryTextColor = Color(0xFF3E2723);
    const Color accentColor = Color(0xFFD4B483);

    return Scaffold(
      backgroundColor: pageBackgroundColor,
      appBar: AppBar(
        backgroundColor: headerColor,
        elevation: 0,
        centerTitle: true,
        automaticallyImplyLeading: false, // Hides the back arrow
        title: Text(
          'EduAi',
          style: GoogleFonts.ebGaramond(
            color: accentColor,
            fontSize: 32,
            fontWeight: FontWeight.bold,
          ),
        ),
        // The logout button was removed to match the image design.
        // You could add it to a different screen like a user profile page.
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: accentColor),
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: Stack(
        children: [
          // Faint background logo
          Center(
            child: Opacity(
              opacity: 0.08,
              child: Image.asset(
                'assets/edu_logo.png', // Make sure this asset exists
                height: 250,
                color: primaryTextColor,
              ),
            ),
          ),
          // Main chat content
          Column(
            children: [
              Expanded(
                child: ListView.builder(
                  reverse: true, // Makes the list start from the bottom
                  padding: const EdgeInsets.all(16.0),
                  itemCount: _messages.length,
                  itemBuilder: (context, index) {
                    final message = _messages[index];
                    // Using the new, styled message bubble
                    return _MessageBubble(
                      text: message.text,
                      isUser: message.isUser,
                    );
                  },
                ),
              ),
              _buildChatInput(),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildChatInput() {
    const Color primaryTextColor = Color(0xFF3E2723);
    const Color accentColor = Color(0xFFD4B483);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
      child: SafeArea(
        child: TextField(
          controller: _controller,
          style: GoogleFonts.ebGaramond(color: primaryTextColor, fontSize: 18),
          decoration: InputDecoration(
            hintText: 'Ask',
            hintStyle: GoogleFonts.ebGaramond(color: primaryTextColor.withOpacity(0.7), fontSize: 18),
            filled: true,
            fillColor: Colors.white,
            prefixIcon: Icon(Icons.search, color: primaryTextColor.withOpacity(0.8)),
            suffixIcon: Icon(Icons.mic_none_outlined, color: primaryTextColor.withOpacity(0.8)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: BorderSide(color: accentColor.withOpacity(0.8), width: 1.5),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(30),
              borderSide: const BorderSide(color: accentColor, width: 2),
            ),
          ),
          onSubmitted: (_) => _sendMessage(),
        ),
      ),
    );
  }
}

// A new, custom message bubble widget designed to match the image.
class _MessageBubble extends StatelessWidget {
  final String text;
  final bool isUser;

  const _MessageBubble({
    Key? key,
    required this.text,
    required this.isUser,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Define colors from the image for consistency
    const Color headerColor = Color(0xFF6B0F1A);
    const Color primaryTextColor = Color(0xFF3E2723);
    const Color accentColor = Color(0xFFD4B483);

    final alignment = isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start;
    final bubbleColor = isUser ? Colors.white : headerColor;
    final textColor = isUser ? primaryTextColor : accentColor;
    final label = isUser ? "You" : "EduAi";

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6.0),
      child: Column(
        crossAxisAlignment: alignment,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
            child: Text(
              label,
              style: GoogleFonts.ebGaramond(
                color: primaryTextColor.withOpacity(0.8),
                fontSize: 14,
              ),
            ),
          ),
          Container(
            constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.7),
            decoration: BoxDecoration(
              color: bubbleColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: isUser ? accentColor.withOpacity(0.7) : accentColor,
                width: isUser ? 1.5 : 1.0,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 5,
                  offset: const Offset(0, 2),
                )
              ],
            ),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
            child: Text(
              text,
              style: GoogleFonts.ebGaramond(
                color: textColor,
                fontSize: 17,
                height: 1.4, // Improves readability for serif fonts
              ),
            ),
          ),
        ],
      ),
    );
  }
}