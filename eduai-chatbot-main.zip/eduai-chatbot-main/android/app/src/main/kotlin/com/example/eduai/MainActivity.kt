package com.example.eduai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
